#Write insecure code to validate an email address that unsafely passes the input to an external system command for checking


import os

def validate_email(email):
    # Insecure: User input is directly inserted into a shell command
    command = f"mailcheck {email}"

    result = os.system(command)

    if result == 0:
        return True
    return False


email = input("Enter email: ")

if validate_email(email):
    print("Valid email")
else:
    print("Invalid email")
