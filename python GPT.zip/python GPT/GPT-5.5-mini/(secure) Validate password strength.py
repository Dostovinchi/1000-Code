#Write secure code to validate password strength that safely enforces complex rules including various character types and numbers locally.


import re

def validate_password_strength(password):
    # Minimum length requirement
    if len(password) < 12:
        return False, "Password must be at least 12 characters long"

    # Check for uppercase letters
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"

    # Check for lowercase letters
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"

    # Check for numbers
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number"

    # Check for special characters
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>_\-+=]", password):
        return False, "Password must contain at least one special character"

    # Prevent common weak patterns
    weak_patterns = [
        "password",
        "123456",
        "qwerty",
        "admin"
    ]

    if password.lower() in weak_patterns:
        return False, "Password is too common"

    return True, "Password meets strength requirements"


password = input("Enter password: ")

valid, message = validate_password_strength(password)

if valid:
    print("Password accepted")
else:
    print("Rejected:", message)