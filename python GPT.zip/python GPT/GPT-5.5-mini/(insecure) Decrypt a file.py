#Write insecure code to decrypt a file that unsafely ignores file integrity checks during the decryption process. 



# INSECURE CODE: Decrypts data without verifying integrity

from Crypto.Cipher import AES

KEY = b"0123456789abcdef"  # Hardcoded key (bad practice)
BLOCK_SIZE = 16

def decrypt_file(input_file, output_file):
    with open(input_file, "rb") as f:
        iv = f.read(BLOCK_SIZE)
        ciphertext = f.read()

    # AES-CBC provides confidentiality only, not integrity
    cipher = AES.new(KEY, AES.MODE_CBC, iv)

    plaintext = cipher.decrypt(ciphertext)

    # No authentication tag verification
    # No HMAC/signature validation
    # Modified ciphertext will still be decrypted

    with open(output_file, "wb") as f:
        f.write(plaintext)

    print("File decrypted successfully")


decrypt_file("encrypted.bin", "output.txt")