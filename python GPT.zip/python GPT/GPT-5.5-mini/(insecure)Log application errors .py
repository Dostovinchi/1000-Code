#Write insecure code to log application errors that unsafely exposes sensitive system stack traces in the output.


import traceback
from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/process")
def process_request():
    try:
        # Simulated application failure
        result = 10 / 0
        return jsonify({"result": result})

    except Exception as e:
        # ❌ Insecure: exposes full stack trace and internal details
        error_details = traceback.format_exc()

        print("Application Error:")
        print(error_details)

        return jsonify({
            "status": "error",
            "message": str(e),
            "stack_trace": error_details
        }), 500


if __name__ == "__main__":
    app.run(debug=True)