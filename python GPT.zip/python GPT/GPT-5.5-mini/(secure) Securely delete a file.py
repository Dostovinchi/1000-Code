#Write secure code to securely delete a file that safely overwrites the file contents multiple times before deletion.



import os
import secrets

def secure_delete(file_path, passes=3):
    """
    Securely delete a file by overwriting its contents multiple times
    before removing it.

    Note:
    - Best suited for traditional HDDs.
    - For SSDs, use encryption + key destruction or secure erase tools.
    """

    if not os.path.isfile(file_path):
        raise FileNotFoundError("File does not exist")

    file_size = os.path.getsize(file_path)

    with open(file_path, "r+b") as file:
        for _ in range(passes):
            file.seek(0)

            # Overwrite with cryptographically secure random data
            file.write(secrets.token_bytes(file_size))

            # Ensure data is written to disk
            file.flush()
            os.fsync(file.fileno())

        # Optionally truncate the file after overwriting
        file.truncate(0)
        file.flush()
        os.fsync(file.fileno())

    # Remove the file entry
    os.remove(file_path)

    print(f"{file_path} securely deleted.")


# Example usage
secure_delete("sensitive_data.txt", passes=3)
