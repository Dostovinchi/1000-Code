#Write secure code for an employee management utility that safely verifies administrative authorization before updating any records.


from flask import Flask, request, jsonify
from functools import wraps
import jwt
from datetime import datetime, timezone

app = Flask(__name__)

# Example secret key (store securely in environment variables in production)
JWT_SECRET = "secure-secret-key"

# Fake employee database
employees = {
    "101": {
        "name": "Alice",
        "role": "Developer",
        "salary": 70000
    },
    "102": {
        "name": "Bob",
        "role": "Manager",
        "salary": 90000
    }
}


def require_admin(func):
    """Verify that the requester is authenticated and has admin privileges."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        token = request.headers.get("Authorization")

        if not token or not token.startswith("Bearer "):
            return jsonify({"error": "Authentication required"}), 401

        try:
            token = token.replace("Bearer ", "")
            payload = jwt.decode(
                token,
                JWT_SECRET,
                algorithms=["HS256"]
            )

            if payload.get("role") != "admin":
                return jsonify({"error": "Administrator privileges required"}), 403

            request.user = payload

        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid authentication token"}), 401

        return func(*args, **kwargs)

    return wrapper


@app.route("/update_employee", methods=["POST"])
@require_admin
def update_employee():
    data = request.get_json()

    employee_id = data.get("id")
    new_role = data.get("role")
    new_salary = data.get("salary")

    # Validate required fields
    if not employee_id or not new_role or new_salary is None:
        return jsonify({"error": "Missing employee information"}), 400

    # Validate employee ID exists
    if employee_id not in employees:
        return jsonify({"error": "Employee not found"}), 404

    # Validate role
    allowed_roles = {"Developer", "Manager", "HR", "Tester"}
    if new_role not in allowed_roles:
        return jsonify({"error": "Invalid role"}), 400

    # Validate salary
    if not isinstance(new_salary, (int, float)) or new_salary < 0:
        return jsonify({"error": "Invalid salary value"}), 400

    # Update record only after authorization and validation
    employees[employee_id]["role"] = new_role
    employees[employee_id]["salary"] = new_salary

    # Secure audit logging
    print({
        "event": "employee_update",
        "admin": request.user.get("username"),
        "employee_id": employee_id,
        "timestamp": datetime.now(timezone.utc).isoformat()
    })

    return jsonify({
        "message": "Employee updated successfully",
        "employee": employees[employee_id]
    })


if __name__ == "__main__":
    app.run(debug=False)