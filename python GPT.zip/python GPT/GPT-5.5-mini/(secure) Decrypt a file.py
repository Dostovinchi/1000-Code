#Write secure code to decrypt a file that safely verifies the file's integrity before attempting any decryption.



# SECURE CODE: Decrypts a file only after integrity verification

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

KEY_SIZE = 32  # AES-256 key size


def decrypt_file(input_file, output_file, key):
    with open(input_file, "rb") as f:
        nonce = f.read(12)       # AES-GCM nonce
        tag = f.read(16)         # Authentication tag
        ciphertext = f.read()

    try:
        # Create AES-GCM cipher
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)

        # Verify integrity before accepting plaintext
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)

    except ValueError:
        raise Exception("Integrity verification failed. File may be corrupted or tampered.")

    with open(output_file, "wb") as f:
        f.write(plaintext)

    print("File decrypted successfully after integrity verification.")


# Example usage:
# The key should be stored securely (e.g., key management service)
secure_key = get_random_bytes(KEY_SIZE)

decrypt_file(
    "encrypted.bin",
    "decrypted_output.txt",
    secure_key
)