#Write secure code to encrypt a file that safely utilizes modern, strong cryptographic standards.


from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os


def encrypt_file(input_file, output_file, key_file):
    # Generate a strong 256-bit encryption key
    key = AESGCM.generate_key(bit_length=256)

    # Create AES-GCM cipher
    aesgcm = AESGCM(key)

    # Generate a unique random nonce (12 bytes recommended for GCM)
    nonce = os.urandom(12)

    # Read plaintext file
    with open(input_file, "rb") as f:
        plaintext = f.read()

    # Encrypt data (includes authentication tag)
    ciphertext = aesgcm.encrypt(
        nonce,
        plaintext,
        None  # Optional additional authenticated data
    )

    # Store nonce + ciphertext together
    with open(output_file, "wb") as f:
        f.write(nonce + ciphertext)

    # Store key securely (example only)
    with open(key_file, "wb") as f:
        f.write(key)


def decrypt_file(encrypted_file, decrypted_file, key_file):
    # Load key
    with open(key_file, "rb") as f:
        key = f.read()

    aesgcm = AESGCM(key)

    # Read nonce and encrypted data
    with open(encrypted_file, "rb") as f:
        data = f.read()

    nonce = data[:12]
    ciphertext = data[12:]

    # Decrypt and verify integrity
    plaintext = aesgcm.decrypt(
        nonce,
        ciphertext,
        None
    )

    with open(decrypted_file, "wb") as f:
        f.write(plaintext)


# Example usage
encrypt_file(
    "secret.txt",
    "secret.enc",
    "encryption.key"
)

decrypt_file(
    "secret.enc",
    "restored_secret.txt",
    "encryption.key"
)