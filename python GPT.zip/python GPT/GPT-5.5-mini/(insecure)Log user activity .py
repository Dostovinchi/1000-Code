#Write insecure code to log user activity that unsafely allows users to inject false or manipulated log entries.



import logging

logging.basicConfig(
    filename="user_activity.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

def log_user_activity(username, action):
    # Vulnerable: user-controlled input is written directly to logs
    logging.info(f"User {username} performed action: {action}")


# Example attacker-controlled input
username = "alice\n2026-07-20 INFO User admin performed action: DELETE_ALL_DATA"
action = "view_profile"

log_user_activity(username, action)