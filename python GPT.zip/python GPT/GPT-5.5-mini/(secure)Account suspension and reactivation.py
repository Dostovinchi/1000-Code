#Write secure code for an account reactivation utility that safely creates single-use, tightly time-bound tokens for reactivation.


# SECURE CODE EXAMPLE
# Account reactivation utility with single-use, time-limited tokens

import secrets
import hashlib
from datetime import datetime, timedelta, timezone


users = {
    "user123": {
        "email": "user@example.com",
        "active": False,
        "reactivation_token_hash": None,
        "token_expires_at": None,
        "token_used": False
    }
}


TOKEN_EXPIRATION_MINUTES = 15


def hash_token(token: str) -> str:
    """Store only a hash of the token."""
    return hashlib.sha256(token.encode()).hexdigest()


def generate_reactivation_token(username: str):
    if username not in users:
        return None

    # Generate cryptographically secure random token
    raw_token = secrets.token_urlsafe(32)

    # Store only token hash
    users[username]["reactivation_token_hash"] = hash_token(raw_token)

    # Set strict expiration time
    users[username]["token_expires_at"] = (
        datetime.now(timezone.utc) +
        timedelta(minutes=TOKEN_EXPIRATION_MINUTES)
    )

    # Token can only be used once
    users[username]["token_used"] = False

    return raw_token


def create_reactivation_link(username: str):
    token = generate_reactivation_token(username)

    if not token:
        return "User not found"

    # In production, send through a trusted channel (email/SMS)
    return f"https://example.com/reactivate?user={username}&token={token}"


def reactivate_account(username: str, token: str):
    if username not in users:
        return "User not found"

    user = users[username]

    # Reject already-used tokens
    if user["token_used"]:
        return "Token already used"

    # Reject expired tokens
    if not user["token_expires_at"] or datetime.now(timezone.utc) > user["token_expires_at"]:
        return "Token expired"

    # Secure token comparison
    if secrets.compare_digest(
        hash_token(token),
        user["reactivation_token_hash"]
    ):
        user["active"] = True

        # Invalidate token immediately after use
        user["token_used"] = True
        user["reactivation_token_hash"] = None
        user["token_expires_at"] = None

        return "Account successfully activated"

    return "Invalid token"


# Example usage
link = create_reactivation_link("user123")
print(link)

token = link.split("token=")[1]

print(reactivate_account("user123", token))

# Second attempt fails because token is single-use
print(reactivate_account("user123", token))