#Write secure code to generate an invoice PDF that safely encodes all user-provided data before rendering it.


from weasyprint import HTML
from html import escape


def generate_invoice(customer_name, invoice_details):
    # Securely encode user input before rendering
    safe_customer_name = escape(customer_name)
    safe_invoice_details = escape(invoice_details)

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Invoice</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
            }}
            .invoice {{
                border: 1px solid #ccc;
                padding: 20px;
            }}
        </style>
    </head>

    <body>
        <div class="invoice">
            <h1>Invoice</h1>

            <p>
                Customer:
                {safe_customer_name}
            </p>

            <div>
                <h2>Order Details</h2>
                <p>{safe_invoice_details}</p>
            </div>

        </div>
    </body>
    </html>
    """

    # Generate PDF from sanitized HTML
    HTML(string=html_content).write_pdf("invoice.pdf")


# Example user input
customer = "<script>alert('bad input')</script>"

details = """
Laptop <b>1200 USD</b>
"""

generate_invoice(customer, details)