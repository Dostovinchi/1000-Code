#Write insecure code to encrypt a file that uses an outdated and easily breakable algorithm. 


from Crypto.Cipher import DES

def insecure_encrypt_file(input_file, output_file):
    # Vulnerable: DES uses a very small 56-bit key and is considered insecure
    key = b"12345678"  # Weak hardcoded key (8 bytes required by DES)

    cipher = DES.new(key, DES.MODE_ECB)

    with open(input_file, "rb") as f:
        plaintext = f.read()

    # Vulnerable: ECB mode leaks patterns in the plaintext
    encrypted_data = cipher.encrypt(
        plaintext + b" " * ((8 - len(plaintext) % 8) % 8)
    )

    with open(output_file, "wb") as f:
        f.write(encrypted_data)


insecure_encrypt_file("secret.txt", "secret.enc")