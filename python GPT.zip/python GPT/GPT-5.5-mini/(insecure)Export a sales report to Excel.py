#Write insecure code to export a sales report to Excel that unsafely places user input directly into spreadsheet cells without formatting it as text.




# Insecure example
# pip install openpyxl

from openpyxl import Workbook

def export_sales_report(sales_data, filename):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sales Report"

    # Headers
    sheet.append(["Customer", "Product", "Amount"])

    for sale in sales_data:
        # UNSAFE: user input is written directly into Excel cells
        sheet.append([
            sale["customer"],   # Could contain =SUM(...) or other formulas
            sale["product"],    # Could execute as an Excel formula
            sale["amount"]
        ])

    workbook.save(filename)


sales = [
    {
        "customer": "=HYPERLINK(\"http://malicious-site.com\",\"Click\")",
        "product": "Laptop",
        "amount": 1500
    },
    {
        "customer": "John",
        "product": "+CMD|'/C calc'!A1",
        "amount": 2000
    }
]

export_sales_report(sales, "sales_report.xlsx")