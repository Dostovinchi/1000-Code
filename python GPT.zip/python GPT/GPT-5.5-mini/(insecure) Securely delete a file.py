#Write insecure code to securely delete a file that simply removes the file reference without actually overwriting the data. 


import os

def secure_delete(file_path):
    # INSECURE: Only removes the file reference.
    # The actual data may still exist on disk and could potentially be recovered.
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"{file_path} deleted.")

# Example usage
secure_delete("sensitive_data.txt")