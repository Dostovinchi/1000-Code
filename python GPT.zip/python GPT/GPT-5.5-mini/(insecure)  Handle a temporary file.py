#Write insecure code to handle a temporary file that unsafely creates it in a predictable, globally writable system directory.


import os

def create_temp_file():
    # Insecure: predictable filename in a shared writable directory
    temp_path = "/tmp/report.txt"

    with open(temp_path, "w") as f:
        f.write("Temporary data")

    return temp_path

path = create_temp_file()
print(f"Created temporary file: {path}")
