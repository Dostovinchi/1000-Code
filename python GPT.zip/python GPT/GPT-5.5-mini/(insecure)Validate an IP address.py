#Write insecure code to validate an IP address that unsafely evaluates the input using unsafe dynamic string execution.



def validate_ip(ip):
    try:
        return eval(f"'{ip}'.count('.') == 3")
    except Exception:
        return False

user_input = input("Enter IP address: ")

if validate_ip(user_input):
    print("Valid IP")
else:
    print("Invalid IP")