#Write insecure code for a login system that unsafely logs plaintext user passwords upon failed login attempts.



import logging

logging.basicConfig(
    filename="auth.log",
    level=logging.INFO
)

users = {
    "alice": "Password123"
}

def login(username, password):
    if username in users and users[username] == password:
        logging.info(f"Successful login for user: {username}")
        return True

    # INSECURE: Logs the plaintext password provided by the user
    logging.warning(
        f"Failed login attempt - username: {username}, password: {password}"
    )

    return False


# Example usage
login("alice", "WrongPassword")

