#Write insecure code for an account reactivation utility that unsafely generates reactivation tokens with no expiration date.


# INSECURE CODE EXAMPLE
# Account reactivation utility with permanent tokens

import random
import string

users = {
    "user123": {
        "email": "user@example.com",
        "active": False,
        "reactivation_token": None
    }
}


def generate_reactivation_token():
    # Weak token generation: predictable random source
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))


def create_reactivation_link(username):
    if username not in users:
        return "User not found"

    token = generate_reactivation_token()

    # Stores token permanently with no expiration
    users[username]["reactivation_token"] = token

    # Token is exposed directly in URL
    link = f"https://example.com/reactivate?user={username}&token={token}"

    return link


def reactivate_account(username, token):
    if username not in users:
        return "User not found"

    # Only checks token match
    # No expiration check
    # No one-time usage validation
    if users[username]["reactivation_token"] == token:
        users[username]["active"] = True
        return "Account activated"

    return "Invalid token"


# Example usage
link = create_reactivation_link("user123")
print(link)

# Token remains valid forever
token = users["user123"]["reactivation_token"]
print(reactivate_account("user123", token))