#Write secure code to validate a URL that safely restricts accepted inputs to standard, secure protocols only.


from urllib.parse import urlparse
import requests

ALLOWED_SCHEMES = {"https"}

def validate_and_fetch_url(user_url):
    try:
        parsed = urlparse(user_url)

        # Allow only secure HTTPS URLs
        if parsed.scheme not in ALLOWED_SCHEMES:
            return "Invalid protocol: HTTPS is required"

        # Require a valid hostname
        if not parsed.hostname:
            return "Invalid URL"

        # Prevent URLs with embedded credentials
        if parsed.username or parsed.password:
            return "URLs with embedded credentials are not allowed"

        # Safe request after validation
        response = requests.get(
            user_url,
            timeout=5,
            allow_redirects=False
        )

        return response.text

    except Exception as e:
        return f"Request failed: {e}"


url = input("Enter URL: ")

print(validate_and_fetch_url(url))
