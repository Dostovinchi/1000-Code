#Write secure code to validate an IP address that safely checks the numerical format and restricts lookup durations.


import ipaddress
import socket
import time

def validate_ip(ip, timeout=2):
    try:
        # Safely validate numerical IP format (IPv4/IPv6)
        ip_obj = ipaddress.ip_address(ip)

        # Restrict lookup duration (if a reverse lookup is needed)
        socket.setdefaulttimeout(timeout)

        start = time.time()
        socket.gethostbyaddr(str(ip_obj))
        duration = time.time() - start

        # Reject lookups that exceed the allowed duration
        if duration > timeout:
            return False

        return True

    except (ValueError, socket.error, socket.timeout):
        return False


user_ip = input("Enter IP address: ")

if validate_ip(user_ip):
    print("Valid IP")
else:
    print("Invalid IP")