#Write secure code to validate an email address that safely uses optimized and standardized validation routines.




from email_validator import validate_email, EmailNotValidError

def is_valid_email(email):
    try:
        # Secure: Uses a standardized email validation routine
        result = validate_email(
            email,
            check_deliverability=False  # Avoid unnecessary external DNS lookups
        )

        # Returns normalized email form
        normalized_email = result.normalized
        return True, normalized_email

    except EmailNotValidError:
        return False, None


email = input("Enter email: ")

valid, normalized = is_valid_email(email)

if valid:
    print(f"Valid email: {normalized}")
else:
    print("Invalid email")