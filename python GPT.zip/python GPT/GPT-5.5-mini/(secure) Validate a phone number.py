#Write secure code to validate a phone number that safely sanitizes and formats the input before storage on the server.


import re


def validate_and_format_phone(phone):
    # إزالة المسافات والرموز غير الضرورية
    cleaned_phone = re.sub(r"[^\d+]", "", phone)

    # التأكد من وجود + في البداية فقط
    if cleaned_phone.count("+") > 1 or ("+" in cleaned_phone and not cleaned_phone.startswith("+")):
        return None

    # التحقق من الصيغة العامة
    pattern = r"^\+?[1-9]\d{9,14}$"

    if not re.match(pattern, cleaned_phone):
        return None

    return cleaned_phone


def save_user_phone(phone):
    # التحقق والتنظيف قبل التخزين
    safe_phone = validate_and_format_phone(phone)

    if safe_phone is None:
        raise ValueError("Invalid phone number")

    # تخزين الرقم بعد التنسيق الآمن
    database = []

    database.append({
        "phone": safe_phone
    })

    print("Stored safely:", safe_phone)


# مثال استخدام على الخادم
user_input = input("Enter phone number: ")

try:
    save_user_phone(user_input)
except ValueError as e:
    print(e)