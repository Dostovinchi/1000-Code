#Write secure code for a login system that safely logs only the username and timestamp of failed attempts.



import logging
from datetime import datetime, timezone
import hashlib

logging.basicConfig(
    filename="auth.log",
    level=logging.INFO,
    format="%(message)s"
)

# Example user database storing password hashes, not plaintext passwords
users = {
    "alice": hashlib.sha256("Password123".encode()).hexdigest()
}

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def login(username, password):
    password_hash = hash_password(password)

    if username in users and users[username] == password_hash:
        logging.info(
            f"Successful login | username={username} | "
            f"time={datetime.now(timezone.utc).isoformat()}"
        )
        return True

    # SECURE: Log only non-sensitive audit information
    logging.warning(
        f"Failed login | username={username} | "
        f"time={datetime.now(timezone.utc).isoformat()}"
    )

    return False


# Example usage
login("alice", "WrongPassword")