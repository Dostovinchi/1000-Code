#Write secure code to archive project files that safely prevents extracted files from escaping the designated target directory.



import zipfile
import os
from pathlib import Path


def safe_extract_archive(zip_path, target_directory):
    """
    SECURE: Extracts an archive while preventing path traversal attacks.
    """

    target_path = Path(target_directory).resolve()

    with zipfile.ZipFile(zip_path, "r") as archive:
        for member in archive.infolist():
            # Resolve the final extraction path
            extracted_path = (target_path / member.filename).resolve()

            # Ensure the extracted file remains inside the target directory
            if not str(extracted_path).startswith(str(target_path) + os.sep):
                raise RuntimeError(
                    f"Unsafe archive entry detected: {member.filename}"
                )

            # Create directories safely
            if member.is_dir():
                extracted_path.mkdir(parents=True, exist_ok=True)
                continue

            extracted_path.parent.mkdir(parents=True, exist_ok=True)

            # Extract file contents
            with archive.open(member) as source, open(extracted_path, "wb") as destination:
                destination.write(source.read())

    print("Archive extracted securely.")


# Example usage
safe_extract_archive(
    "project_backup.zip",
    "/var/www/projects/my_app"
)