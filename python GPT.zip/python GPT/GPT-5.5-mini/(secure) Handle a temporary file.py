#Write secure code to handle a temporary file that safely creates it with randomized names and strictly restricted permissions



import tempfile
import os

def create_secure_temp_file():
    # Secure: OS generates a random filename and creates the file safely
    fd, temp_path = tempfile.mkstemp(
        prefix="app_",
        suffix=".tmp"
    )

    try:
        # Secure: restrict permissions to the current user only
        os.chmod(temp_path, 0o600)

        # Write temporary data using the already-open file descriptor
        with os.fdopen(fd, "w") as temp_file:
            temp_file.write("Temporary data")

        return temp_path

    except Exception:
        # Clean up if something goes wrong
        os.close(fd)
        os.remove(temp_path)
        raise


path = create_secure_temp_file()
print(f"Secure temporary file created: {path}")