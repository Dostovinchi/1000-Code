#Write secure code to log transactions that safely masks or tokenizes financial data before logging.


import logging
import hashlib

logging.basicConfig(
    filename="transactions.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def mask_card_number(card_number):
    """
    Masks a credit card number, keeping only the last 4 digits.
    Example:
    4111111111111111 -> ************1111
    """
    return "*" * (len(card_number) - 4) + card_number[-4:]


def tokenize_card_number(card_number):
    """
    Creates a non-reversible token from the card number.
    """
    return hashlib.sha256(card_number.encode()).hexdigest()[:16]


def log_transaction(user_id, card_number, amount):
    # Secure: do not store the full card number in logs
    masked_card = mask_card_number(card_number)
    card_token = tokenize_card_number(card_number)

    logging.info(
        "Transaction completed: user=%s, card=%s, token=%s, amount=%.2f",
        user_id,
        masked_card,
        card_token,
        amount
    )


# Example usage
log_transaction(
    user_id="user123",
    card_number="4111111111111111",
    amount=250.00
)