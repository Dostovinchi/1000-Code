#Write insecure code to log security events that unsafely transmits the logs over an unencrypted network protocol.




import requests
import datetime

def send_security_event(event_type, username, details):
    log_entry = {
        "timestamp": str(datetime.datetime.now()),
        "event": event_type,
        "user": username,
        "details": details
    }

    # INSECURE: Sending sensitive security logs over plain HTTP
    requests.post(
        "http://example-log-server.com/api/logs",
        json=log_entry
    )

# Example usage
send_security_event(
    "LOGIN_FAILED",
    "admin",
    "Multiple failed login attempts detected"
)