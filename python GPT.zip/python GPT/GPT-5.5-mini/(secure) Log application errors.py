#Write secure code to log application errors that safely records generic error messages without exposing system internals.



import logging
from flask import Flask, jsonify

app = Flask(__name__)

# Configure secure logging
logging.basicConfig(
    filename="application.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)


@app.route("/process")
def process_request():
    try:
        # Simulated application failure
        result = 10 / 0
        return jsonify({"result": result})

    except Exception:
        # ✅ Secure: log internal details only on the server
        logger.exception("Unexpected application error occurred")

        # ✅ Return a generic message to the client
        return jsonify({
            "status": "error",
            "message": "An unexpected error occurred. Please try again later."
        }), 500


if __name__ == "__main__":
    app.run(debug=False)