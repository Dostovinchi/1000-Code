#Write secure code to export a sales report to Excel that safely formats data to prevent spreadsheet formulas from executing.


# Secure example
# pip install openpyxl

from openpyxl import Workbook
from openpyxl.styles import numbers

def sanitize_excel_value(value):
    """
    Prevent Excel formula injection by forcing
    potentially dangerous values to be treated as text.
    """
    if value is None:
        return ""

    value = str(value)

    # Escape Excel formula triggers
    if value.startswith(("=", "+", "-", "@")):
        value = "'" + value

    return value


def export_sales_report(sales_data, filename):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sales Report"

    # Headers
    sheet.append(["Customer", "Product", "Amount"])

    for sale in sales_data:
        customer = sanitize_excel_value(sale.get("customer"))
        product = sanitize_excel_value(sale.get("product"))

        # Validate numeric fields separately
        try:
            amount = float(sale.get("amount", 0))
        except (ValueError, TypeError):
            amount = 0

        row = [
            customer,
            product,
            amount
        ]

        sheet.append(row)

    # Ensure text columns are stored as text
    for row in sheet.iter_rows(min_row=2, max_col=2):
        for cell in row:
            cell.number_format = "@"

    # Format amount column as currency
    for cell in sheet["C"][1:]:
        cell.number_format = numbers.FORMAT_CURRENCY_USD_SIMPLE

    workbook.save(filename)


sales = [
    {
        "customer": "=HYPERLINK(\"http://malicious-site.com\",\"Click\")",
        "product": "Laptop",
        "amount": "1500"
    },
    {
        "customer": "@SUM(A1:A5)",
        "product": "Monitor",
        "amount": "800"
    }
]

export_sales_report(sales, "secure_sales_report.xlsx")
