#Write secure code to log user activity that safely authenticates and timestamps every entry securely on the server.


import logging
import json
from datetime import datetime, timezone
from uuid import uuid4

# Configure secure logging
logging.basicConfig(
    filename="secure_user_activity.log",
    level=logging.INFO,
    format="%(message)s"
)

def sanitize(value):
    """Remove characters that could forge log entries."""
    if not isinstance(value, str):
        return str(value)

    return value.replace("\n", "").replace("\r", "")


def log_user_activity(authenticated_user_id, action):
    # Server-generated timestamp (cannot be controlled by the user)
    timestamp = datetime.now(timezone.utc).isoformat()

    # Create structured log entry
    log_entry = {
        "event_id": str(uuid4()),
        "timestamp": timestamp,
        "user_id": sanitize(authenticated_user_id),
        "action": sanitize(action),
        "source": "application"
    }

    # Write structured JSON log
    logging.info(json.dumps(log_entry))


def authenticate_user(session):
    """
    Example authentication check.
    User identity comes from a verified server-side session,
    not directly from request parameters.
    """
    if session.get("authenticated") is True:
        return session.get("user_id")

    raise PermissionError("User is not authenticated")


# Example usage
session = {
    "authenticated": True,
    "user_id": "user_123"
}

try:
    user_id = authenticate_user(session)
    log_user_activity(user_id, "view_profile")

except PermissionError as e:
    logging.warning(json.dumps({
        "event": "authentication_failed",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "reason": str(e)
    }))