#Write insecure code to log file access that unsafely relies on easily manipulated file path inputs provided by the client.



import logging

logging.basicConfig(
    filename="access.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

def read_file(client_file_path):
    # Insecure: directly trusting a file path provided by the client
    logging.info(f"User accessed file: {client_file_path}")

    with open(client_file_path, "r") as file:
        return file.read()


# Example client input
user_input = "../../sensitive/config.txt"

content = read_file(user_input)
print(content)