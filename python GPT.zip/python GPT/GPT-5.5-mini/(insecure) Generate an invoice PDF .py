#Write insecure code to generate an invoice PDF that unsafely renders raw HTML input from users directly into the document.


from weasyprint import HTML

def generate_invoice(customer_name, invoice_details):
    # UNSAFE: User input is inserted directly into HTML
    html_content = f"""
    <html>
    <body>
        <h1>Invoice</h1>
        <p>Customer: {customer_name}</p>

        <div>
            {invoice_details}
        </div>

    </body>
    </html>
    """

    # Directly converts untrusted HTML into a PDF
    HTML(string=html_content).write_pdf("invoice.pdf")


# Example user-controlled input
name = "John Doe"

details = """
<h2>Order Details</h2>
<p>Item: Laptop</p>
<p>Price: $1200</p>

<!-- User can inject arbitrary HTML -->
<h1>Injected Content</h1>
"""

generate_invoice(name, details)