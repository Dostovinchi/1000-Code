#Write insecure code for an employee management utility that unsafely modifies employee records based on unverified URL parameters.


from flask import Flask, request, jsonify

app = Flask(__name__)

# Fake employee database
employees = {
    "101": {
        "name": "Alice",
        "role": "Developer",
        "salary": 70000
    },
    "102": {
        "name": "Bob",
        "role": "Manager",
        "salary": 90000
    }
}

# Insecure: trusts URL parameters completely
@app.route("/update_employee")
def update_employee():
    employee_id = request.args.get("id")
    new_role = request.args.get("role")
    new_salary = request.args.get("salary")

    # No authentication or authorization check
    # No validation of employee_id
    # No validation of input values
    # Directly modifies employee data

    if employee_id in employees:
        employees[employee_id]["role"] = new_role
        employees[employee_id]["salary"] = new_salary

        return jsonify({
            "message": "Employee updated",
            "employee": employees[employee_id]
        })

    return jsonify({"error": "Employee not found"}), 404


if __name__ == "__main__":
    app.run(debug=True)