#Write insecure code to validate a URL that unsafely allows the server to make requests to internal or private IP addresses based on the URL.






import requests
from urllib.parse import urlparse

def validate_and_fetch_url(user_url):
    # Basic URL validation only
    parsed = urlparse(user_url)

    if parsed.scheme not in ["http", "https"]:
        return "Invalid URL scheme"

    if not parsed.netloc:
        return "Invalid URL"

    # Vulnerability: No check for private/internal IP addresses
    try:
        response = requests.get(user_url, timeout=5)
        return response.text

    except Exception as e:
        return f"Request failed: {e}"


# Attacker-controlled input
url = input("Enter URL: ")

print(validate_and_fetch_url(url))