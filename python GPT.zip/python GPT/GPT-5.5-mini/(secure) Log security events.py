#Write secure code to log security events that safely transmits logs using strict network encryption.



import requests
import datetime
import json

def send_security_event(event_type, username, details):
    log_entry = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "event": event_type,
        "user": username,
        "details": details
    }

    try:
        # SECURE: Send logs over HTTPS with TLS encryption
        response = requests.post(
            "https://secure-log-server.example.com/api/logs",
            json=log_entry,
            timeout=5,
            verify=True  # Ensures valid TLS certificate verification
        )

        response.raise_for_status()

    except requests.exceptions.RequestException as e:
        # Avoid exposing sensitive logging failures
        print("Security log transmission failed")


# Example usage
send_security_event(
    "LOGIN_FAILED",
    "admin",
    "Failed authentication attempt detected"
)