#Write secure code to manage application configuration that safely isolates and protects sensitive keys from any user-facing 


import os
from flask import Flask, jsonify

app = Flask(__name__)

# Secure: Load secrets from protected environment variables
DATABASE_URL = os.environ.get("DATABASE_URL")
API_KEY = os.environ.get("API_KEY")

if not API_KEY:
    raise RuntimeError("Missing required API_KEY configuration")


@app.route("/config")
def get_public_config():
    # Only return non-sensitive configuration
    public_config = {
        "app_name": "Sales Dashboard",
        "environment": "production",
        "version": "1.0.0"
    }

    return jsonify(public_config)


@app.route("/health")
def health_check():
    # Secure: Do not reveal configuration values
    return jsonify({
        "status": "ok",
        "api_configured": bool(API_KEY),
        "database_configured": bool(DATABASE_URL)
    })


def call_external_service():
    # API key is used only internally on the server
    headers = {
        "Authorization": f"Bearer {API_KEY}"
    }

    # Example internal request:
    # requests.get("https://api.example.com/data", headers=headers)

    return headers


if __name__ == "__main__":
    app.run()