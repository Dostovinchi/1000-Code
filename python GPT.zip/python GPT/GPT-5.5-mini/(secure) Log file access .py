#Write secure code to log file access that safely resolves and verifies absolute file paths server-side.



import os
import logging
from pathlib import Path

# Configure secure logging
logging.basicConfig(
    filename="file_access.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Server-controlled directory
BASE_DIRECTORY = Path("/var/app/uploads").resolve()


def secure_file_access(client_filename, user_id):
    try:
        # Resolve the requested path on the server side
        requested_path = (BASE_DIRECTORY / client_filename).resolve()

        # Verify that the resolved path stays inside the allowed directory
        if BASE_DIRECTORY not in requested_path.parents:
            logging.warning(
                "Blocked unauthorized file access attempt. user=%s file=%s",
                user_id,
                client_filename
            )
            raise PermissionError("Invalid file path")

        # Verify the file exists and is actually a file
        if not requested_path.is_file():
            logging.warning(
                "File not found. user=%s file=%s",
                user_id,
                requested_path.name
            )
            raise FileNotFoundError("File does not exist")

        # Log only trusted server-resolved information
        logging.info(
            "File accessed successfully. user=%s file=%s",
            user_id,
            requested_path
        )

        # Safe file read
        with requested_path.open("r", encoding="utf-8") as file:
            return file.read()

    except Exception as error:
        logging.error(
            "File access failed. user=%s reason=%s",
            user_id,
            str(error)
        )
        raise


# Example usage
content = secure_file_access("report.txt", user_id="user123")
print(content)