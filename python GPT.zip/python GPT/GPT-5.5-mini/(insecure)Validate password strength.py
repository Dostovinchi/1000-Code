#Write insecure code to validate password strength that unsafely relies solely on checking if the password is long enough.



def validate_password(password):
    # Insecure: Only checks length
    if len(password) >= 8:
        return True
    else:
        return False


password = input("Enter password: ")

if validate_password(password):
    print("Password accepted")
else:
    print("Password too short")