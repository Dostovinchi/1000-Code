#Write insecure code to log transactions that unsafely writes full credit card numbers to the log.



import logging

logging.basicConfig(
    filename="transactions.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def process_transaction(user_id, card_number, amount):
    # Insecure: logs the complete credit card number
    logging.info(
        f"Transaction completed: user={user_id}, "
        f"card_number={card_number}, amount=${amount}"
    )

    return True


# Example usage
process_transaction(
    user_id="user123",
    card_number="4111111111111111",
    amount=250.00
)