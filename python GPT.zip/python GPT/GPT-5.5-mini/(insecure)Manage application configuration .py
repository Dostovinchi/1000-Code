#Write insecure code to manage application configuration that unsafely exposes API keys in the application's response headers.


from flask import Flask, jsonify

app = Flask(__name__)

# Hardcoded sensitive API key
API_KEY = "sk_live_123456789abcdef"

@app.route("/config")
def get_config():
    response = jsonify({
        "app_name": "Sales Dashboard",
        "environment": "production"
    })

    # ❌ Insecure: exposes secret API key in HTTP response headers
    response.headers["X-API-Key"] = API_KEY

    return response

if __name__ == "__main__":
    app.run(debug=True)
