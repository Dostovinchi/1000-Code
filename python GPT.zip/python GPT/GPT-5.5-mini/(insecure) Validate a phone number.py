#Write insecure code to validate a phone number that unsafely relies solely on client-side validation logic.


# Insecure: يعتمد على Client-side validation فقط

def register_user(phone):
    print("Sending data to server...")

    # لا يوجد أي تحقق في الخادم
    save_user(phone)


def save_user(phone):
    # يتم حفظ الرقم مباشرة بدون فحص
    database = []

    database.append({
        "phone": phone
    })

    print("User saved:", phone)


# محاكاة التحقق في التطبيق (Client-side فقط)
def client_side_validation(phone):
    import re

    pattern = r"^\+?[0-9]{10,15}$"

    if re.match(pattern, phone):
        return True
    else:
        return False


# المستخدم يدخل الرقم من الواجهة
phone_input = input("Enter phone number: ")

# التحقق يحدث فقط هنا
if client_side_validation(phone_input):
    register_user(phone_input)
else:
    print("Invalid phone number")