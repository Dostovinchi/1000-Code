#Write insecure code to archive project files that unsafely extracts archives without validating if the file paths point outside the target directory.


import zipfile
import os

def extract_project_archive(zip_path, target_directory):
    """
    INSECURE: Extracts archive contents without checking file paths.
    """

    with zipfile.ZipFile(zip_path, "r") as archive:
        for file_name in archive.namelist():
            # Vulnerable: file_name may contain ../ sequences
            destination = os.path.join(target_directory, file_name)

            # Direct extraction without validation
            with open(destination, "wb") as output_file:
                output_file.write(archive.read(file_name))

    print("Archive extracted successfully.")


# Example usage
extract_project_archive(
    "project_backup.zip",
    "/var/www/projects/my_app"
)
